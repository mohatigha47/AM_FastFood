package com.example.mohhaythemg2fastfood

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Spinner

class MainActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {
    lateinit var mySpinner : Spinner
    override fun onCreate(savedInstanceState: Bundle?) {
        val foodList = mutableListOf<FastFood>(
            FastFood("Hamburger",150,R.drawable.i1),
            FastFood("Pizza",250,R.drawable.i2),
            FastFood("Taco",130,R.drawable.i3),
            FastFood("M7jouba",210,R.drawable.i4),
        )
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mySpinner = findViewById(R.id.spinner)
        mySpinner.adapter = DropAdapter(this,android.R.layout.simple_list_item_1,foodList)
        mySpinner.setOnItemSelectedListener(this)

    }

    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {

    }

    override fun onNothingSelected(p0: AdapterView<*>?) {

    }


}