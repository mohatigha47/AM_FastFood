package com.example.mohhaythemg2fastfood

data class FastFood(val name:String,val price:Int,val imageID:Int)
