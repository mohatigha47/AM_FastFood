package com.example.mohhaythemg2fastfood

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView

class MyAdapter(context: Context, resource: Int,val data: MutableList<FastFood>):
    ArrayAdapter<FastFood>(context, resource,data ) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

         val inflater : LayoutInflater = LayoutInflater.from(context)
        val view : View = inflater.inflate(R.layout.item,parent,false)
        val tvName = view.findViewById<TextView>(R.id.tvName)
        val tvPrice = view.findViewById<TextView>(R.id.tvPrice)
        val imgView = view.findViewById<ImageView>(R.id.imageView)
        tvName.setText(data.get(position).name)

        imgView.setImageResource(data.get(position).imageID)
        tvPrice.setText(data.get(position).price.toString()+"$")
        return view
    }
}