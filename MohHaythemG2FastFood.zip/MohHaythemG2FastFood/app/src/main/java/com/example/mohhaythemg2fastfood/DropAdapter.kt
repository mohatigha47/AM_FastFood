package com.example.mohhaythemg2fastfood

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*

class DropAdapter(context: Context, resource: Int,val data: MutableList<FastFood>):
    ArrayAdapter<FastFood>(context, resource, data) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val inflater : LayoutInflater = LayoutInflater.from(context)
        val view : View = inflater.inflate(R.layout.drop_selected,parent,false)
        val tvName = view.findViewById<TextView>(R.id.tvdsName)
        val tvPrice = view.findViewById<TextView>(R.id.tvdsPrice)
        val imgView = view.findViewById<ImageView>(R.id.imgdsView)
        val eatButton = view.findViewById<Button>(R.id.eatsButton)
        eatButton.setOnClickListener {
            var removed = data.get(position)
            data.removeAt(position)
            notifyDataSetChanged()
            Toast.makeText(
                context,
                "You ate ${removed.name}\n Pay ${removed.price}$ please",
                Toast.LENGTH_SHORT
            ).show()
        }
        tvName.setText(data.get(position).name)

        imgView.setImageResource(data.get(position).imageID)
        tvPrice.setText(data.get(position).price.toString()+"$")
        return view
    }

    override fun getCount(): Int {
        return data.size
    }

    override fun getItem(position: Int): FastFood? {
        return data.get(position)
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
        val inflater : LayoutInflater = LayoutInflater.from(context)
        val view : View = inflater.inflate(R.layout.drop,parent,false)
        val tvName = view.findViewById<TextView>(R.id.tvdName)
        val tvPrice = view.findViewById<TextView>(R.id.tvdPrice)
        val imgView = view.findViewById<ImageView>(R.id.imgdView)
        tvName.setText(data.get(position).name)

        imgView.setImageResource(data.get(position).imageID)
        tvPrice.setText(data.get(position).price.toString()+"$")
        return view
    }
}